import express from 'express';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(express.json());

const BOT_TOKEN = process.env.BOT_TOKEN;
const CHAT_ID = process.env.CHAT_ID;

// Endpoint start sewa
app.post('/sfr', async (req, res) => {
  const { id, nama, durasi } = req.body;
  if (!id || !nama || !durasi) return res.json({ message: 'Isi semua data!' });

  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: CHAT_ID, text: `Sewa baru dimulai!\nID: ${id}\nNama: ${nama}\nDurasi: ${durasi}` })
  });

  res.json({ message: `Sewa ID ${id} berhasil dimulai.` });
});

// Endpoint stop sewa
app.post('/stop', async (req, res) => {
  const { id } = req.body;
  if (!id) return res.json({ message: 'Isi ID!' });

  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: CHAT_ID, text: `Sewa dihentikan!\nID: ${id}` })
  });

  res.json({ message: `Sewa ID ${id} berhasil dihentikan.` });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
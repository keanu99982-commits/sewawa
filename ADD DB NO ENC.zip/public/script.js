// ======================
// Menu toggle
// ======================
const menuBtn = document.getElementById('menuBtn');
const menuPanel = document.getElementById('menuPanel');

menuBtn.addEventListener('click', () => {
  menuPanel.style.display = menuPanel.style.display === 'block' ? 'none' : 'block';
});

// ======================
// Tab Withdraw / Activity
// ======================
const tabWithdraw = document.getElementById('tabWithdraw');
const tabActivity = document.getElementById('tabActivity');
const contentWithdraw = document.getElementById('contentWithdraw');
const contentActivity = document.getElementById('contentActivity');

tabWithdraw.addEventListener('click', () => {
  contentWithdraw.style.display = 'block';
  contentActivity.style.display = 'none';
  tabWithdraw.classList.add('activeTab');
  tabActivity.classList.remove('activeTab');
});

tabActivity.addEventListener('click', () => {
  contentWithdraw.style.display = 'none';
  contentActivity.style.display = 'block';
  tabActivity.classList.add('activeTab');
  tabWithdraw.classList.remove('activeTab');
});

// ======================
// Saldo dengan LocalStorage
// ======================
let saldo = parseInt(localStorage.getItem('saldo') || '0');
document.getElementById('saldoDisplay').textContent = `Saldo: Rp ${saldo}`;

function updateSaldo(amount){
  saldo += amount;
  localStorage.setItem('saldo', saldo);
  document.getElementById('saldoDisplay').textContent = `Saldo: Rp ${saldo}`;
}

// ======================
// Withdraw
// ======================
document.getElementById('btnWithdraw').addEventListener('click', () => {
  const amount = parseInt(document.getElementById('withdrawAmount').value);
  const method = document.getElementById('withdrawMethod').value;
  const number = document.getElementById('withdrawNumber').value.trim();

  if(isNaN(amount) || amount < 10000) return alert('Minimal withdraw Rp 10.000');
  if(amount > saldo) return alert('Saldo tidak cukup');
  if(number === '') return alert('Masukkan nomor');

  updateSaldo(-amount);

  // Tambahkan ke activity
  const li = document.createElement('li');
  li.textContent = `Withdraw Rp ${amount} ke ${method} (${number})`;
  document.getElementById('activityList').appendChild(li);

  alert('Withdraw berhasil! Silahkan cek activity.');
});

// ======================
// Start / Stop Sewa (API Node.js)
// ======================
async function startSewa() {
  const id = document.getElementById('sewaId').value.trim();
  const nama = document.getElementById('nama').value.trim();
  const durasi = document.getElementById('durasi').value;

  if (!id || !nama || !durasi) return alert('Isi semua data!');

  const res = await fetch('/sfr', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id, nama, durasi })
  });
  const data = await res.json();
  alert(data.message);

  // Tambahkan ke activity
  const li = document.createElement('li');
  li.textContent = `Sewa dimulai - ID: ${id}, Nama: ${nama}, Durasi: ${durasi}`;
  document.getElementById('activityList').appendChild(li);
}

async function stopSewa() {
  const id = document.getElementById('sewaId').value.trim();
  if (!id) return alert('Isi ID!');

  const res = await fetch('/stop', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id })
  });
  const data = await res.json();
  alert(data.message);

  const li = document.createElement('li');
  li.textContent = `Sewa dihentikan - ID: ${id}`;
  document.getElementById('activityList').appendChild(li);
}
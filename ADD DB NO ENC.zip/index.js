import express from 'express';
import path from 'path';

const app = express();
const PORT = 3000;

app.use(express.static(path.join(path.resolve(), 'public')));

// Penting: bind ke 0.0.0.0 supaya bisa diakses dari perangkat lain
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${PORT}`);
});